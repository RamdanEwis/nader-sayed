// eslint-disable-next-line import/no-anonymous-default-export
export default {
    USER_ID: `xCNspFvG99I3kQBhR`,
    TEMPLATE_ID: `template_3vxhk2f`,
    SERVICE_ID: "service_ojs52ff"
}